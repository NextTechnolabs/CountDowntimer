package com.zw.countdowntimer.core

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Created by Janak on 27/12/23.
 */

@HiltAndroidApp
class CountDownTimerApp: Application() {

}